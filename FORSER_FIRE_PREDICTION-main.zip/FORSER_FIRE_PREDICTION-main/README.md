# Forest-Fire-Prediction-Website
A website that predicts the probability of a forest fire taking place based on oxygen,temperature and humidity content
